"""
visualizations.py
-------------------
Every chart in AGRIVISTA is built here so the app has one consistent
visual language: a shared Plotly template and the AGRIVISTA color system.

Color system (premium agricultural palette):
    Primary    Deep Forest Green   #123C2F  -> chart chrome, titles
    Secondary  Emerald             #2E7D5B  -> normal / default data
    Accent     Fresh Lime          #A8C957  -> secondary series accent
    Highlight  Golden Harvest      #E6B84A  -> #1 / key result ONLY
    Warning    Terracotta          #D96C4F  -> warnings / lowest point
    Background Warm Ivory         #F7F5EE  -> paper/plot background
    Text       Dark Charcoal      #18302A  -> body text / axis labels

No rainbow colors. Normal data uses muted greens/neutrals; the single
highlighted / #1 item uses Golden Harvest; warnings use Terracotta.
"""

import numpy as np
import pandas as pd
import plotly.graph_objects as go

# ----------------------------------------------------------------------
# Design tokens
# ----------------------------------------------------------------------

DEEP_GREEN = "#123C2F"
EMERALD = "#2E7D5B"
LIME = "#A8C957"
GOLD = "#E6B84A"
TERRACOTTA = "#D96C4F"
IVORY = "#F7F5EE"
CHARCOAL = "#18302A"

MUTED_GRID = "#E4E0D3"
CARD_WHITE = "#FFFFFF"

# Sequential scale (light ivory -> deep forest green) for gradients/heat-style bars
SEQUENTIAL_GREEN = ["#F7F5EE", "#DCE9DE", "#BFDAC4", "#9FC7A9",
                     "#7DB18E", "#5C9B76", "#3E845F", "#2E7D5B", "#123C2F"]

# Muted, earthy categorical palette for multi-crop comparisons (boxplots,
# side-by-side comparisons). Deliberately NOT a rainbow — all tones sit in
# the green/neutral/harvest family.
CATEGORICAL_PALETTE = [
    "#2E7D5B", "#8FA88C", "#A8C957", "#5C7A5A",
    "#B7B18C", "#4F6F52", "#7DAE9A", "#C9BE8E",
    "#3E6B57", "#93A480",
]

FONT_FAMILY = "'Inter', 'Segoe UI', sans-serif"


def _base_layout(fig: go.Figure, title: str = None, height: int = 420) -> go.Figure:
    fig.update_layout(
        title=dict(text=title, font=dict(size=17, color=DEEP_GREEN, family=FONT_FAMILY), x=0.02, xanchor="left") if title else None,
        font=dict(family=FONT_FAMILY, color=CHARCOAL, size=13),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=10, r=10, t=55 if title else 20, b=10),
        height=height,
        hoverlabel=dict(bgcolor=CARD_WHITE, font_size=13, font_family=FONT_FAMILY, bordercolor=EMERALD),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1, bgcolor="rgba(0,0,0,0)"),
    )
    fig.update_xaxes(showgrid=True, gridcolor=MUTED_GRID, zeroline=False)
    fig.update_yaxes(showgrid=True, gridcolor=MUTED_GRID, zeroline=False)
    return fig


# 1. Generic ranked bar chart (highlights #1 in Golden Harvest) -----------

def ranked_bar_chart(df: pd.DataFrame, cat_col: str, val_col: str, unit_label: str = "",
                      title: str = None, top_n: int = 10, height: int = 440) -> go.Figure:
    """Horizontal ranked bar chart used across Overview / Crop / State
    pages. The #1 (highest value) bar is highlighted in Golden Harvest;
    every other bar uses a muted green so the eye goes straight to the
    winner without a rainbow of colors."""
    data = df.sort_values(val_col, ascending=False).head(top_n).sort_values(val_col)
    n = len(data)
    colors = [GOLD if i == n - 1 else EMERALD for i in range(n)]
    axis_label = f"{val_col.replace('_', ' ')} ({unit_label})" if unit_label else val_col.replace("_", " ")
    fig = go.Figure(go.Bar(
        x=data[val_col], y=data[cat_col], orientation="h",
        marker=dict(color=colors, line=dict(width=0)),
        hovertemplate=f"<b>%{{y}}</b><br>{axis_label}: " + "%{x:,.2f}<extra></extra>",
    ))
    fig = _base_layout(fig, title=title, height=height)
    fig.update_xaxes(title=axis_label)
    fig.update_yaxes(title=None)
    return fig


# 2. Yield boxplot ---------------------------------------------------------

def yield_boxplot(df: pd.DataFrame, crops: list, height: int = 480, unit_label: str = "tonnes/hectare") -> go.Figure:
    data = df[df["Crop"].isin(crops)] if crops else df
    order = data.groupby("Crop")["Yield"].median().sort_values(ascending=False).index.tolist()
    fig = go.Figure()
    for i, crop in enumerate(order):
        sub = data[data["Crop"] == crop]
        fig.add_trace(go.Box(
            y=sub["Yield"], name=crop, marker_color=CATEGORICAL_PALETTE[i % len(CATEGORICAL_PALETTE)],
            boxpoints="outliers", marker=dict(size=4, opacity=0.6), line=dict(width=1.5),
        ))
    fig = _base_layout(fig, title=f"Yield Distribution by Crop ({unit_label})", height=height)
    fig.update_xaxes(title=None, tickangle=-25, categoryorder="array", categoryarray=order)
    fig.update_yaxes(title=f"Yield ({unit_label})")
    fig.update_layout(showlegend=False)
    return fig


# 3. Production / yield trend over years (highlights peak & lowest year) --

def yearly_trend_chart(df: pd.DataFrame, height: int = 420, value_col: str = "Production",
                        value_label: str = "Total Production (tonnes)") -> go.Figure:
    """Clean single-metric line + subtle area fill, with the peak year and
    lowest year called out explicitly (per design spec: highlight peak &
    lowest, no other annotations)."""
    fig = go.Figure()
    if value_col not in df.columns or not len(df):
        return _base_layout(fig, title=value_label, height=height)

    data = df.sort_values("Crop_Year")
    fig.add_trace(go.Scatter(
        x=data["Crop_Year"], y=data[value_col], mode="lines", name=value_label,
        line=dict(color=EMERALD, width=3), fill="tozeroy", fillcolor="rgba(46,125,91,0.12)",
        hovertemplate="Year %{x}<br>" + value_label + ": %{y:,.2f}<extra></extra>",
    ))

    peak_row = data.loc[data[value_col].idxmax()]
    low_row = data.loc[data[value_col].idxmin()]
    fig.add_trace(go.Scatter(
        x=[peak_row["Crop_Year"]], y=[peak_row[value_col]], mode="markers+text", name="Peak Year",
        marker=dict(color=GOLD, size=13, line=dict(width=2, color=DEEP_GREEN)),
        text=[f"Peak · {int(peak_row['Crop_Year'])}"], textposition="top center",
        hovertemplate="Peak Year %{x}<br>" + value_label + ": %{y:,.2f}<extra></extra>",
    ))
    fig.add_trace(go.Scatter(
        x=[low_row["Crop_Year"]], y=[low_row[value_col]], mode="markers+text", name="Lowest Year",
        marker=dict(color=TERRACOTTA, size=13, line=dict(width=2, color=DEEP_GREEN)),
        text=[f"Lowest · {int(low_row['Crop_Year'])}"], textposition="bottom center",
        hovertemplate="Lowest Year %{x}<br>" + value_label + ": %{y:,.2f}<extra></extra>",
    ))

    fig = _base_layout(fig, title=value_label + " Over Time", height=height)
    fig.update_xaxes(title="Year")
    fig.update_yaxes(title=value_label)
    fig.update_layout(showlegend=False)
    return fig


# 5. Stability chart --------------------------------------------------------

def stability_chart(ranking: pd.DataFrame, top_n: int = 15, height: int = 440) -> go.Figure:
    data = ranking.head(top_n).sort_values("stability_score")
    n = len(data)
    colors = [GOLD if i == n - 1 else EMERALD for i in range(n)]
    fig = go.Figure(go.Bar(
        x=data["stability_score"], y=data["Crop"], orientation="h",
        marker=dict(color=colors),
        hovertemplate="<b>%{y}</b><br>Stability Score: %{x:.3f}<extra></extra>",
    ))
    fig = _base_layout(fig, title="Crop Stability Ranking (higher = more consistent yield)", height=height)
    fig.update_xaxes(title="Stability Score (0-1)", range=[0, 1])
    fig.update_yaxes(title=None)
    return fig


# 6. ML result charts --------------------------------------------------------

def model_comparison_chart(results: pd.DataFrame, height: int = 360) -> go.Figure:
    colors = [GOLD if i == 0 else EMERALD for i in range(len(results))]
    fig = go.Figure(go.Bar(
        x=results["Model"], y=results["R2"], marker=dict(color=colors),
        text=results["R2"].round(3), textposition="outside",
        hovertemplate="<b>%{x}</b><br>R²: %{y:.4f}<extra></extra>",
    ))
    fig = _base_layout(fig, title="Model Comparison — R² (higher is better)", height=height)
    fig.update_yaxes(title="R² Score")
    fig.update_xaxes(title=None)
    return fig


def actual_vs_predicted_chart(y_true, y_pred, height: int = 440) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=y_true, y=y_pred, mode="markers", marker=dict(color=EMERALD, opacity=0.5, size=6),
        name="Predictions", hovertemplate="Actual: %{x:,.2f}<br>Predicted: %{y:,.2f}<extra></extra>",
    ))
    lo, hi = float(np.min(y_true)), float(np.max(y_true))
    fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines",
                              line=dict(color=TERRACOTTA, dash="dash", width=2), name="Perfect Prediction"))
    fig = _base_layout(fig, title="Actual vs Predicted Yield (Test Set)", height=height)
    fig.update_xaxes(title="Actual Yield")
    fig.update_yaxes(title="Predicted Yield")
    return fig


def feature_importance_chart(importances: pd.DataFrame, height: int = 400) -> go.Figure:
    data = importances.sort_values("Importance").tail(10)
    n = len(data)
    colors = [GOLD if i == n - 1 else EMERALD for i in range(n)]
    fig = go.Figure(go.Bar(
        x=data["Importance"], y=data["Feature"], orientation="h",
        marker=dict(color=colors),
        hovertemplate="<b>%{y}</b><br>Importance: %{x:.4f}<extra></extra>",
    ))
    fig = _base_layout(fig, title="Feature Importance", height=height)
    fig.update_xaxes(title="Relative Importance")
    fig.update_yaxes(title=None)
    return fig


def what_if_chart(scenario_df: pd.DataFrame, vary_col: str, height: int = 400) -> go.Figure:
    fig = go.Figure(go.Scatter(
        x=scenario_df[vary_col], y=scenario_df["Predicted Yield"], mode="lines+markers",
        line=dict(color=EMERALD, width=3), marker=dict(size=8, color=GOLD),
        hovertemplate=f"{vary_col}: " + "%{x}<br>Predicted Yield: %{y:,.2f}<extra></extra>",
    ))
    fig = _base_layout(fig, title=f"Model-Based Scenario: Predicted Yield vs {vary_col.replace('_', ' ')}", height=height)
    fig.update_xaxes(title=vary_col.replace("_", " "))
    fig.update_yaxes(title="Predicted Yield")
    return fig
