"""
AGRIVISTA — Smart Agricultural Crop Production, Yield Intelligence &
Prediction Platform
=======================================================================
Main Streamlit entry point. Handles page routing and UI composition.
All data cleaning, analysis, visualization, and ML logic lives in the
src/ package so this file stays focused on layout.

Navigation is intentionally simple (5 pages): Overview, Crop Analysis,
State Analysis, Yield Prediction, Methodology. Filters are LOCAL to the
page that needs them — there is no global sidebar filter, so changing a
selection on one page can never unexpectedly alter another page.
"""

import os
import sys

import pandas as pd
import streamlit as st

sys.path.append(os.path.dirname(__file__))

from src import data_loader, preprocessing, analysis, statistics as stats_mod
from src import insights as insights_mod, visualizations as viz, ml_model

# ------------------------------------------------------------------
# Page config & global styling
# ------------------------------------------------------------------

st.set_page_config(
    page_title="AGRIVISTA | Crop Yield Intelligence",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded",
)

CSS_PATH = os.path.join(os.path.dirname(__file__), "assets", "style.css")
with open(CSS_PATH) as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)


# ------------------------------------------------------------------
# Small UI helpers
# ------------------------------------------------------------------

def kpi_card(icon: str, label: str, value: str, sub: str = "") -> str:
    return f"""
    <div class="kpi-card">
        <div class="kpi-icon">{icon}</div>
        <div class="kpi-label">{label}</div>
        <div class="kpi-value">{value}</div>
        <div class="kpi-sub">{sub}</div>
    </div>
    """


def section_header(eyebrow: str, title: str):
    st.markdown(
        f'<div class="section-eyebrow">{eyebrow}</div><div class="section-title">{title}</div>',
        unsafe_allow_html=True,
    )


def fmt_num(n, decimals=0):
    if n is None or (isinstance(n, float) and pd.isna(n)):
        return "—"
    if abs(n) >= 1_000_000_000:
        return f"{n/1_000_000_000:,.2f}B"
    if abs(n) >= 1_000_000:
        return f"{n/1_000_000:,.2f}M"
    if abs(n) >= 1_000:
        return f"{n/1_000:,.1f}K"
    return f"{n:,.{decimals}f}"


def metric_chip(label, value):
    return f'<div class="metric-chip"><div class="val">{value}</div><div class="lab">{label}</div></div>'


def callout(msg: str, kind: str = "info"):
    st.markdown(f'<div class="callout-box {kind}">{msg}</div>', unsafe_allow_html=True)


def insight_card(icon: str, label: str, finding: str):
    st.markdown(
        f'<div class="insight-card"><b>{icon} {label}</b><br>{finding}</div>',
        unsafe_allow_html=True,
    )


def empty_state(msg="No data available for this selection."):
    st.info(f"ℹ️ {msg}")


def boxplot_legend():
    st.markdown(
        '<div class="boxplot-key">'
        '<span><b>Center line</b> = median</span>'
        '<span><b>Box</b> = middle 50% of values</span>'
        '<span><b>Whiskers</b> = typical range</span>'
        '<span><b>Points</b> = potential outliers</span>'
        '</div>',
        unsafe_allow_html=True,
    )


COCONUT_NOTE = (
    "🥥 **Unit note:** Coconut is reported in *nuts/hectare* (and total nuts for "
    "Production), while every other crop here is reported in *tonnes/hectare* "
    "(and total tonnes). Coconut is therefore excluded from cross-crop Yield and "
    "Production comparisons by default, and remains available for its own "
    "crop-specific exploration. See Methodology for details."
)

# Short form used on pages where the full banner would just repeat what's
# already shown once (in the Crop Analysis boxplot section) or in full
# detail on the Methodology page — avoids stacking the same paragraph on
# every page that happens to exclude Coconut from a comparison.
COCONUT_NOTE_SHORT = "🥥 Coconut excluded from this comparison — different yield units (see Methodology)."

# ------------------------------------------------------------------
# Load & clean data (once, cached)
# ------------------------------------------------------------------

df_full, colmap, cleaning_report = data_loader.load_clean_data()
available = colmap.available()

# ------------------------------------------------------------------
# Sidebar — navigation only (no global filters)
# ------------------------------------------------------------------

with st.sidebar:
    st.markdown(
        '<div class="nav-brand">🌾 AGRIVISTA</div>'
        '<div class="nav-brand-sub">Agricultural Intelligence Platform</div>',
        unsafe_allow_html=True,
    )

    page = st.radio(
        "Navigate",
        [
            "🏠 Overview",
            "🌱 Crop Analysis",
            "📍 State Analysis",
            "🤖 Yield Prediction",
            "ℹ️ Methodology",
        ],
        label_visibility="collapsed",
    )

    st.markdown("<hr>", unsafe_allow_html=True)
    st.caption(
        f"📊 {len(df_full):,} records · {df_full['Crop'].nunique()} crops · "
        f"{df_full['State'].nunique()} states · {int(df_full['Crop_Year'].min())}–{int(df_full['Crop_Year'].max())}"
    )
    st.caption("Filters live on each page and never affect other pages.")


# ========================================================================
# PAGE 1 — OVERVIEW
# ========================================================================

def render_overview():
    st.markdown(
        """
        <div class="hero-wrap">
            <span class="hero-badge">Data-Driven Agriculture</span>
            <span class="hero-badge">Machine Learning</span>
            <div class="hero-title">🌾 AGRIVISTA</div>
            <div class="hero-subtitle">Agricultural Intelligence Platform</div>
            <div class="hero-desc">Understanding India's crop production landscape.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if not preprocessing.safe_dataframe(df_full):
        empty_state()
        return

    kpis = analysis.compute_kpis(df_full)

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(kpi_card("📦", "Total Production (tonnes)", fmt_num(kpis["total_production"]), "comparable-unit crops"), unsafe_allow_html=True)
    with c2:
        st.markdown(kpi_card("📈", "Avg Yield (tonnes/hectare)", f"{kpis['avg_yield']:.2f}" if kpis["avg_yield"] is not None else "—", "comparable-unit crops"), unsafe_allow_html=True)
    with c3:
        st.markdown(kpi_card("🌱", "Crops Tracked", str(kpis["num_crops"]), ""), unsafe_allow_html=True)
    with c4:
        st.markdown(kpi_card("🗺️", "States / Regions", str(kpis["num_states"]), ""), unsafe_allow_html=True)

    st.markdown("<div class='soft-divider'></div>", unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Mandatory Analysis", "Top Producing Crops")
    prod = analysis.production_by_crop(df_full, top_n=10)
    if len(prod):
        st.plotly_chart(viz.ranked_bar_chart(prod, "Crop", "Production", unit_label="tonnes",
                                              title="Top 10 Producing Crops (tonnes)", top_n=10),
                         use_container_width=True)
    else:
        empty_state()
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Mandatory Analysis", "Production Journey")
    yt = analysis.yearly_trend(df_full)
    if len(yt) and "Production" in yt.columns:
        st.plotly_chart(viz.yearly_trend_chart(yt, value_col="Production", value_label="Total Production (tonnes)"),
                         use_container_width=True)
    else:
        empty_state()
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Automatic Insight Engine", "AGRIVISTA Insight")

    if kpis.get("top_crop"):
        top_prod_crop = analysis.production_by_crop(df_full, top_n=1)["Crop"].iloc[0]
        insight_card("🌾", "Production Leader",
                     f"<b>{top_prod_crop}</b> leads total production among comparable-unit crops.")
        insight_card("🏆", "Yield Leader",
                     f"<b>{kpis['top_crop']}</b> achieves the highest average yield "
                     f"({kpis['top_crop_yield']:.2f} t/ha) among comparable-unit crops.")
    movers = analysis.top_movers(df_full, "Yield")
    if movers.get("max_increase"):
        up = movers["max_increase"]
        insight_card("📈", "Trend",
                     f"The largest year-over-year rise in average yield occurred in "
                     f"<b>{up['Crop_Year']}</b> (+{up['delta']:.2f} t/ha).")
    if kpis.get("most_stable_crop"):
        insight_card("🛡️", "Most Stable Crop",
                     f"<b>{kpis['most_stable_crop']}</b> shows the most consistent yield across "
                     f"years and regions (stability score {kpis['most_stable_score']:.2f}).")
    st.markdown('</div>', unsafe_allow_html=True)


# ========================================================================
# PAGE 2 — CROP ANALYSIS
# ========================================================================

def render_crop_analysis():
    st.markdown("## 🌱 Crop Analysis")
    st.caption("Production, yield, and distribution — per crop.")

    if not preprocessing.safe_dataframe(df_full):
        empty_state()
        return

    comparable = data_loader.comparable_yield_df(df_full)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Local Filter", "Choose a Crop")
    all_crops_full = sorted(df_full["Crop"].unique())
    default_idx = all_crops_full.index("Rice") if "Rice" in all_crops_full else 0
    single_crop = st.selectbox("Crop", all_crops_full, index=default_idx, key="crop_select")

    is_coconut = ml_model.is_excluded_from_general_model(single_crop)
    unit = "nuts/hectare" if is_coconut else "tonnes/hectare"
    if is_coconut:
        callout(
            "🥥 Coconut is reported in <b>nuts/hectare</b>, not tonnes/hectare. The figures "
            "below describe Coconut on its own and are not comparable to any other crop's "
            "numbers shown elsewhere in this app.",
            "warn",
        )

    crop_df = df_full[df_full["Crop"] == single_crop]
    if len(crop_df):
        yield_stats = stats_mod.crop_summary_stats(crop_df).iloc[0]
        prod_stats = stats_mod.production_summary_stats(crop_df).iloc[0]
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.markdown(metric_chip("Avg Production", fmt_num(prod_stats["mean"])), unsafe_allow_html=True)
        with m2:
            st.markdown(metric_chip("Total Production", fmt_num(prod_stats["total"])), unsafe_allow_html=True)
        with m3:
            st.markdown(metric_chip(f"Avg Yield ({unit})", f"{yield_stats['mean']:.2f}"), unsafe_allow_html=True)
        with m4:
            st.markdown(metric_chip("Stability Score", f"{yield_stats['stability_score']:.3f}"), unsafe_allow_html=True)
    else:
        empty_state()
    st.markdown('</div>', unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Ranking", "Average Production Ranking")
        avg_prod = analysis.avg_production_by_crop(df_full, top_n=10)
        if len(avg_prod):
            st.plotly_chart(viz.ranked_bar_chart(avg_prod, "Crop", "Production", unit_label="tonnes",
                                                  title="Top 10 Crops by Average Production", top_n=10),
                             use_container_width=True)
        else:
            empty_state()
        st.markdown('</div>', unsafe_allow_html=True)
    with col2:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Mandatory Analysis", "Highest Yielding Crops")
        top_yield = analysis.avg_yield_by_crop(df_full, top_n=10)
        if len(top_yield):
            st.plotly_chart(viz.ranked_bar_chart(top_yield, "Crop", "Yield", unit_label="tonnes/hectare",
                                                  title="Top 10 Highest-Yielding Crops", top_n=10),
                             use_container_width=True)
        else:
            empty_state()
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Mandatory Analysis", "Yield Distribution (Boxplot)")
    callout(COCONUT_NOTE, "warn")
    boxplot_legend()
    stats = stats_mod.crop_summary_stats(comparable)
    default_crops = stats["Crop"].head(6).tolist()
    chosen = st.multiselect(
        "Crops to compare (max 10, for readable labels)",
        sorted(comparable["Crop"].unique()), default=default_crops,
        max_selections=10, key="box_crops",
    )
    if chosen:
        st.plotly_chart(viz.yield_boxplot(comparable, chosen), use_container_width=True)
    else:
        empty_state("Select at least one crop.")
    st.markdown('</div>', unsafe_allow_html=True)


# ========================================================================
# PAGE 3 — STATE ANALYSIS
# ========================================================================

def render_state_analysis():
    st.markdown("## 📍 State Analysis")
    st.caption("State-level production and yield performance.")

    if not preprocessing.safe_dataframe(df_full):
        empty_state()
        return

    st.caption(COCONUT_NOTE_SHORT)
    comparable = data_loader.comparable_yield_df(df_full)
    state_sum = analysis.statewise_summary(df_full)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Mandatory Analysis", "Top States by Production")
        if len(state_sum):
            st.plotly_chart(viz.ranked_bar_chart(state_sum, "State", "Production", unit_label="tonnes",
                                                  title="Top 10 States by Production", top_n=10),
                             use_container_width=True)
        else:
            empty_state()
        st.markdown('</div>', unsafe_allow_html=True)
    with col2:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Mandatory Analysis", "Top States by Average Yield")
        if len(state_sum) and "Yield" in state_sum.columns:
            yield_sorted = state_sum.dropna(subset=["Yield"])
            st.plotly_chart(viz.ranked_bar_chart(yield_sorted, "State", "Yield", unit_label="tonnes/hectare",
                                                  title="Top 10 States by Average Yield", top_n=10),
                             use_container_width=True)
        else:
            empty_state()
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Local Filter", "Explore a State")
    all_states = sorted(df_full["State"].unique())
    sel_state = st.selectbox("State", all_states, key="state_select")

    state_comparable = comparable[comparable["State"] == sel_state]
    if len(state_comparable):
        total_prod = state_comparable["Production"].sum()
        avg_yield = state_comparable["Yield"].mean()
        top_crop_series = state_comparable.groupby("Crop")["Production"].sum().sort_values(ascending=False)
        top_crop = top_crop_series.index[0] if len(top_crop_series) else "—"

        m1, m2, m3 = st.columns(3)
        with m1:
            st.markdown(metric_chip("Total Production (tonnes)", fmt_num(total_prod)), unsafe_allow_html=True)
        with m2:
            st.markdown(metric_chip("Average Yield (t/ha)", f"{avg_yield:.2f}"), unsafe_allow_html=True)
        with m3:
            st.markdown(metric_chip("Top Crop", top_crop), unsafe_allow_html=True)

        st.markdown("<div class='soft-divider'></div>", unsafe_allow_html=True)
        yt = state_comparable.groupby("Crop_Year", as_index=False).agg(Production=("Production", "sum"))
        st.plotly_chart(viz.yearly_trend_chart(yt, value_col="Production",
                                                value_label=f"{sel_state} — Total Production (tonnes)"),
                         use_container_width=True)
    else:
        empty_state("No comparable-unit crop data available for this state.")
    st.markdown('</div>', unsafe_allow_html=True)


# ========================================================================
# PAGE 4 — YIELD PREDICTION
# ========================================================================

def render_prediction():
    st.markdown("## 🤖 Yield Prediction")
    st.caption("Model comparison, evaluation, interactive prediction, and what-if scenarios. Uses the FULL dataset for training.")

    required = {"Crop", "State", "Season", "Crop_Year", "Area", "Yield"}
    if not required.issubset(df_full.columns):
        empty_state("The dataset is missing columns required for yield prediction.")
        return

    leak_check = analysis.yield_area_relationship_check(df_full)
    callout(
        f"🚨 <b>Leakage check</b>: correlation between Yield and Production/Area = "
        f"<b>{leak_check['correlation']:.4f}</b> (computed live, {leak_check['n_rows_checked']:,} rows). "
        f"Because Yield can be almost exactly reconstructed from Production ÷ Area, "
        f"<b>Production is excluded</b> from every model's feature set.",
        "warn",
    )
    st.caption(COCONUT_NOTE_SHORT)

    with st.spinner("Training models..."):
        results, trained, (cat_cols, num_cols), random_best_name = ml_model.train_and_compare(df_full)
        ta = ml_model.train_time_aware(df_full)
        primary_model, primary_name, (p_cat, p_num), primary_source = ml_model.get_primary_model(df_full)

    callout(
        "Because yield prediction is intended for <b>future</b> use, AGRIVISTA uses chronological "
        "(time-aware) validation as the <b>primary</b> model-selection strategy. Random-split "
        "results are shown for comparison but are not used to select the primary model.",
        "info",
    )

    tab1, tab2, tab3, tab4 = st.tabs([
        "⏳ Time-Aware Validation (Primary)", "🔮 Predict Yield",
        "🔬 What-If Scenario", "📊 Random Split (Reference)",
    ])

    with tab1:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Scientific Validity · Primary Evaluation", "Time-Aware (Chronological) Validation")
        st.markdown(
            "A random 80/20 split lets the model see records from *later* years during training "
            "and get tested on *earlier* years — unrealistic for forecasting. This evaluates the "
            "same models trained on the **earliest years only** and tested on the **most recent "
            "years**, which is the basis on which the **primary deployed model** is selected."
        )
        if ta is None:
            empty_state("Not enough distinct years in the dataset for a meaningful chronological split.")
        else:
            st.caption(
                f"Trained on {ta['train_years'][0]}–{ta['train_years'][1]} ({ta['n_train']:,} rows) · "
                f"Tested on {ta['test_years'][0]}–{ta['test_years'][1]} ({ta['n_test']:,} rows) · "
                f"Split point: end of {ta['cutoff_year']} · Comparable-unit crops only (Coconut excluded)"
            )
            st.dataframe(
                ta["results"].style.format({"R2": "{:.4f}", "MAE": "{:.3f}", "RMSE": "{:.3f}"}),
                use_container_width=True,
            )
            st.caption("R² is a goodness-of-fit measure (0-1, higher is better) — not 'accuracy'. MAE and RMSE are in tonnes/hectare.")
            insight_card("🏆", "Primary Deployed Model",
                         f"<b>{primary_name}</b> is selected as the primary deployed model (highest time-aware R²). "
                         f"It powers the Predict Yield and What-If Scenario tools.")
        st.markdown('</div>', unsafe_allow_html=True)

        if ta is not None:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown('<div class="section-card">', unsafe_allow_html=True)
                section_header(f"Primary Model: {primary_name}", "Actual vs Predicted Yield")
                st.plotly_chart(viz.actual_vs_predicted_chart(primary_model.y_test, primary_model.y_pred), use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
            with col2:
                st.markdown('<div class="section-card">', unsafe_allow_html=True)
                section_header(f"Primary Model: {primary_name}", "Feature Importance")
                fi = ml_model.get_feature_importance(primary_model, p_cat, p_num)
                if len(fi):
                    st.plotly_chart(viz.feature_importance_chart(fi), use_container_width=True)
                    st.caption("Feature importance reflects influence on predictions. It does not prove causation.")
                else:
                    st.info(f"{primary_name} does not expose feature importances (e.g. a linear model).")
                st.markdown('</div>', unsafe_allow_html=True)

    with tab2:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header(f"Interactive · Primary Model: {primary_name}", "Predict Yield for a New Scenario")

        in_crop = st.selectbox("Crop", sorted(df_full["Crop"].unique()), key="pred_crop")

        if ml_model.is_excluded_from_general_model(in_crop):
            callout(
                f"🥥 <b>{in_crop}</b> is measured in <b>nuts/hectare</b> and is therefore excluded "
                f"from the general comparable-unit prediction model. A prediction here would mix "
                f"units and would not be scientifically meaningful. {in_crop} remains available "
                f"for crop-specific exploration on the Crop Analysis page.",
                "warn",
            )
        else:
            c1, c2 = st.columns(2)
            with c1:
                in_state = st.selectbox("State", sorted(df_full["State"].unique()), key="pred_state")
                in_season = st.selectbox("Season", sorted(df_full["Season"].unique()), key="pred_season")
            with c2:
                in_year = st.number_input("Year", min_value=1997, max_value=2035, value=2024, key="pred_year")
                in_area = st.number_input("Area (hectares)", min_value=0.1, value=1000.0, key="pred_area")

            c4, c5, c6 = st.columns(3)
            with c4:
                in_rain = st.number_input("Annual Rainfall (mm)", min_value=0.0, value=float(df_full["Annual_Rainfall"].median()), key="pred_rain") if "Annual_Rainfall" in p_num else None
            with c5:
                in_fert = st.number_input("Fertilizer (kg)", min_value=0.0, value=float(df_full["Fertilizer"].median()), key="pred_fert") if "Fertilizer" in p_num else None
            with c6:
                in_pest = st.number_input("Pesticide (kg)", min_value=0.0, value=float(df_full["Pesticide"].median()), key="pred_pest") if "Pesticide" in p_num else None

            input_dict = {"Crop": in_crop, "State": in_state, "Season": in_season, "Crop_Year": in_year, "Area": in_area,
                           "Annual_Rainfall": in_rain, "Fertilizer": in_fert, "Pesticide": in_pest}

            if st.button("🔮 PREDICT YIELD", type="primary"):
                pred = ml_model.predict_single(primary_model, input_dict, p_cat + p_num)
                st.markdown(
                    f"""
                    <div class="predict-result">
                        <div class="predict-label">Predicted Yield (tonnes/hectare)</div>
                        <div class="predict-value">{pred:,.2f}</div>
                        <div class="predict-label">{primary_name} · time-aware selected</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                mc1, mc2, mc3 = st.columns(3)
                with mc1:
                    st.markdown(metric_chip("R² (time-aware)", f"{primary_model.r2:.3f}"), unsafe_allow_html=True)
                with mc2:
                    st.markdown(metric_chip("MAE", f"{primary_model.mae:.2f}"), unsafe_allow_html=True)
                with mc3:
                    st.markdown(metric_chip("RMSE", f"{primary_model.rmse:.2f}"), unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

    with tab3:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header(f"Model-Based Scenario Analysis · Primary Model: {primary_name}", "What-If Scenario")
        callout(
            "This tool shows what the trained model <i>predicts</i> as one input changes, holding "
            "all others fixed. It reflects the model's learned association, not a guaranteed "
            "real-world causal effect.",
            "info",
        )

        comparable_crops = sorted(data_loader.comparable_yield_df(df_full)["Crop"].unique())
        if not comparable_crops:
            empty_state("No comparable-unit crops available for scenario analysis.")
        else:
            c1, c2, c3 = st.columns(3)
            with c1:
                base_crop = st.selectbox("Crop", comparable_crops, key="wi_crop")
                base_state = st.selectbox("State", sorted(df_full["State"].unique()), key="wi_state")
            with c2:
                base_season = st.selectbox("Season", sorted(df_full["Season"].unique()), key="wi_season")
                base_year = st.number_input("Year", min_value=1997, max_value=2035, value=2024, key="wi_year")
            with c3:
                base_area = st.number_input("Area (hectares)", min_value=0.1, value=1000.0, key="wi_area")

            base_rain = float(df_full["Annual_Rainfall"].median()) if "Annual_Rainfall" in num_cols else None
            base_fert = float(df_full["Fertilizer"].median()) if "Fertilizer" in num_cols else None
            base_pest = float(df_full["Pesticide"].median()) if "Pesticide" in num_cols else None
            base_input = {"Crop": base_crop, "State": base_state, "Season": base_season, "Crop_Year": base_year,
                          "Area": base_area, "Annual_Rainfall": base_rain, "Fertilizer": base_fert, "Pesticide": base_pest}

            vary_options = [c for c in ["Annual_Rainfall", "Fertilizer", "Pesticide", "Area"] if c in num_cols]
            vary_col = st.selectbox("Variable to vary", vary_options, key="wi_vary")

            base_val = base_input[vary_col]
            lo, hi = base_val * 0.3, base_val * 2.0
            sweep_values = list(pd.RangeIndex(0, 9).map(lambda i: lo + (hi - lo) * i / 8))

            scenario_df = ml_model.what_if_scenario(primary_model, base_input, cat_cols + num_cols, vary_col, sweep_values)
            st.plotly_chart(viz.what_if_chart(scenario_df, vary_col), use_container_width=True)
            st.caption(
                f"Model-based scenario analysis using the primary (time-aware selected) model: each "
                f"point is the model's prediction with only {vary_col.replace('_', ' ')} changed. "
                "Not a guaranteed real-world outcome."
            )
        st.markdown('</div>', unsafe_allow_html=True)

    with tab4:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        section_header("Random 80/20 Split · Reference Only", "Model Comparison")
        st.caption("Shown for comparison. Not used to select the primary deployed model — see the Time-Aware tab.")
        st.plotly_chart(viz.model_comparison_chart(results), use_container_width=True)
        st.dataframe(
            results.style.format({"R2": "{:.4f}", "MAE": "{:.3f}", "RMSE": "{:.3f}"}),
            use_container_width=True,
        )
        st.caption("R² is a goodness-of-fit measure (0-1, higher is better) — not 'accuracy'. Comparable-unit crops only.")
        st.markdown('</div>', unsafe_allow_html=True)


# ========================================================================
# PAGE 5 — METHODOLOGY
# ========================================================================

def render_methodology():
    st.markdown("## ℹ️ Methodology")
    st.caption("A judge-friendly explanation of how this platform's numbers are produced.")

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Dataset", "Source & Scope")
    st.markdown(
        f"- **Records:** {cleaning_report.original_rows:,} raw → {cleaning_report.cleaned_rows:,} after cleaning\n"
        f"- **Coverage:** {int(df_full['Crop_Year'].min())}–{int(df_full['Crop_Year'].max())}, "
        f"{df_full['State'].nunique()} states, {df_full['Crop'].nunique()} crops\n"
        f"- **Columns:** {', '.join([k for k, v in available.items() if v])}"
    )
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Data Cleaning", "What Was Done — And Why")
    st.markdown(
        f"- Text columns stripped of whitespace: {', '.join(cleaning_report.text_columns_stripped) or 'none needed'}\n"
        f"- Duplicate rows removed: **{cleaning_report.duplicate_rows_removed}**\n"
        f"- Rows removed for missing essential fields: **{cleaning_report.missing_value_rows_removed}**\n"
        f"- Rows removed for invalid (negative) numeric values: **{cleaning_report.invalid_numeric_rows_removed}**\n"
        f"- Total rows removed: **{cleaning_report.rows_removed}** of {cleaning_report.original_rows:,}"
    )
    for note in cleaning_report.notes:
        callout(note, "info")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Data Quality", "Unit Limitation — Coconut")
    callout(
        "Yield units differ in the source dataset. <b>Coconut</b> is reported in "
        "<b>nuts/hectare</b> (and total nuts for Production), while every other crop is "
        "reported in <b>tonnes/hectare</b> (and total tonnes). Direct numerical comparison "
        "is therefore not meaningful. This platform excludes Coconut from every cross-crop "
        "Yield and Production ranking, total, and KPI by default, while keeping it available "
        "for crop-specific analysis (its own boxplot, stability score, etc.).",
        "warn",
    )
    callout(
        "🥥 This exclusion extends to the <b>machine learning models</b>: the general yield "
        "prediction model is trained only on the comparable tonnes/hectare crop subset, so "
        "Coconut's nuts-based Yield never enters the shared regression target. Coconut is not "
        "removed from the dataset — selecting it in the Predict Yield tab shows a clear "
        "explanatory message instead of a misleading cross-unit prediction.",
        "warn",
    )
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Feature Engineering & Leakage Prevention", "Why Production Is Excluded from ML")
    leak_check = analysis.yield_area_relationship_check(df_full)
    st.markdown(
        f"Yield in this dataset is (almost) exactly Production ÷ Area — verified live on the "
        f"current data: correlation between reported Yield and computed Production/Area = "
        f"**{leak_check['correlation']:.4f}** across {leak_check['n_rows_checked']:,} rows. "
        f"Because Yield can be reconstructed almost exactly from Production, including "
        f"Production as a model feature would let the model 'cheat' via near-exact division "
        f"rather than learn genuine agronomic relationships — producing an inflated R² that "
        f"would not generalize to real forecasting (where the season's Production is not yet "
        f"known). **Production is therefore excluded from every model's feature set.** Area is "
        f"kept: on its own, Area does not determine Yield, and it is a genuine, independently-"
        f"known agronomic input."
    )
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Model Evaluation & Selection", "Random vs. Time-Aware Validation")
    st.markdown(
        "This dataset spans multiple years (1997–2020). A random 80/20 split can let the model "
        "train on records from later years and get evaluated on earlier years — unrealistic for "
        "forecasting, since future data is never available at training time. This platform "
        "reports **both**: a standard random split, and a **time-aware split** (train on the "
        "earliest years, test on the most recent years).\n\n"
        "**Because yield prediction is intended for future use, AGRIVISTA uses chronological "
        "validation as the primary model-selection strategy.** The model type deployed to the "
        "interactive Predict Yield and What-If Scenario tools is whichever model scores highest "
        "on the time-aware evaluation — not whichever happens to score highest on the random "
        "split. Random-split results remain visible on the Yield Prediction page for comparison, "
        "but are not used as the basis for model selection."
    )
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("ML Models Compared", "Algorithms & Metrics")
    st.markdown(
        "- **Linear Regression** — simple, interpretable baseline\n"
        "- **Decision Tree Regressor** — captures non-linear splits\n"
        "- **Random Forest Regressor** — ensemble of trees, typically strong on tabular data\n"
        "- **Gradient Boosting Regressor** — sequential ensemble, often the strongest fit\n\n"
        "Evaluated with **R²** (goodness of fit, 0–1, higher is better — never called "
        "'accuracy'), **MAE** (mean absolute error, same units as Yield), and **RMSE** "
        "(root mean squared error, penalizes larger errors more)."
    )
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    section_header("Limitations", "What This Platform Does Not Claim")
    st.markdown(
        "- Correlations shown (rainfall, fertilizer, pesticide vs. yield) are associations, "
        "**not proof of causation**.\n"
        "- The What-If tool shows model-based scenario predictions, not guaranteed real-world "
        "agronomic outcomes.\n"
        "- Coconut's raw yield/production numbers are not comparable to other crops due to "
        "differing units (see above).\n"
        "- The dataset does not include soil quality, irrigation infrastructure, crop variety, "
        "or farming practice — factors that materially affect real yields but are not present "
        "here."
    )
    st.markdown('</div>', unsafe_allow_html=True)


# ========================================================================
# ROUTER
# ========================================================================

PAGES = {
    "🏠 Overview": render_overview,
    "🌱 Crop Analysis": render_crop_analysis,
    "📍 State Analysis": render_state_analysis,
    "🤖 Yield Prediction": render_prediction,
    "ℹ️ Methodology": render_methodology,
}

PAGES[page]()
